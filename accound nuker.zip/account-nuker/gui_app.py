#!/usr/bin/env python3
"""
account-nuker GUI — Local web dashboard
Run: python3 gui_app.py  →  opens http://localhost:7734
"""

import sys, subprocess, importlib, importlib.util

REQUIRED = {
    "flask":      "flask",
    "requests":   "requests",
    "bs4":        "beautifulsoup4",
    "imap_tools": "imap-tools",
    "click":      "click",
}

def _ensure_deps():
    missing = [pkg for mod, pkg in REQUIRED.items()
               if not importlib.util.find_spec(mod)]
    if not missing:
        return
    print(f"[account-nuker] Installing: {', '.join(missing)}")
    for flag in [["--break-system-packages"], ["--user"]]:
        r = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--quiet"] + flag + missing,
            capture_output=True)
        if r.returncode == 0:
            break

_ensure_deps()

import os, re, json, csv, time, threading, queue, logging, shutil
import imaplib, email as email_lib, getpass, webbrowser, tempfile, sqlite3
from pathlib import Path
from datetime import datetime, timedelta
from urllib.parse import urlparse
from email.header import decode_header
from typing import Optional
from flask import Flask, Response, request, jsonify, stream_with_context
import requests

# ── Config ────────────────────────────────────────────────────────────────────
APP_DIR    = Path.home() / ".account-nuker"
CREDS_FILE = APP_DIR / "creds.json"
JDM_CACHE  = APP_DIR / "jdm.json"
LOG_FILE   = Path.home() / "account-nuker.log"
REPORT_CSV = Path.home() / "account-nuker-report.csv"
PORT       = 7734

logging.basicConfig(filename=str(LOG_FILE), level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("account-nuker-gui")

# ── Shared state ──────────────────────────────────────────────────────────────
_state = {
    "accounts":    [],
    "scan_running": False,
    "auto_running": False,
    "auto_results": [],
    "log_queue":    queue.Queue(),
}

# ── Re-use logic from app.py / browser_automation.py ─────────────────────────
sys.path.insert(0, str(Path(__file__).parent))
try:
    from app import (fetch_jdm, scan_email, scan_browser_history,
                     match_to_jdm, generate_gdpr_email, save_creds,
                     load_creds, delete_creds, export_csv, NOISE_DOMAINS,
                     IMAP_HOSTS, _app_password_hint)
except ImportError:
    # Inline minimal versions if app.py not present
    NOISE_DOMAINS = {"google.com","googleapis.com","gstatic.com","gmail.com",
                     "yahoo.com","outlook.com","hotmail.com","microsoft.com",
                     "apple.com","icloud.com","cloudflare.com","amazonaws.com"}
    def fetch_jdm(force_refresh=False): return {}
    def scan_email(e, p, dry_run=False): return set()
    def scan_browser_history(): return set()
    def match_to_jdm(d, j): return []
    def generate_gdpr_email(sn, se, ue, dom): return ""
    def save_creds(e, p): pass
    def load_creds(): return None
    def delete_creds(): pass
    def export_csv(a): pass
    def _app_password_hint(e): return ""

# ── Flask app ─────────────────────────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = os.urandom(24)

def _emit(msg: str, kind: str = "log"):
    _state["log_queue"].put({"type": kind, "message": msg,
                              "ts": datetime.now().strftime("%H:%M:%S")})

# ── API routes ────────────────────────────────────────────────────────────────
@app.route("/api/creds", methods=["GET"])
def get_creds():
    stored = load_creds()
    if stored:
        return jsonify({"saved": True, "email": stored[0]})
    return jsonify({"saved": False, "email": ""})

@app.route("/api/creds", methods=["POST"])
def set_creds():
    data = request.json
    save_creds(data["email"], data["password"])
    return jsonify({"ok": True})

@app.route("/api/creds", methods=["DELETE"])
def del_creds():
    delete_creds()
    return jsonify({"ok": True})

@app.route("/api/scan", methods=["POST"])
def start_scan():
    if _state["scan_running"]:
        return jsonify({"error": "Scan already running"}), 400
    data        = request.json or {}
    dry_run     = data.get("dry_run", False)
    email_only  = data.get("email_only", False)
    browser_only= data.get("browser_only", False)
    force_jdm   = data.get("force_jdm", False)
    stored      = load_creds()
    email_addr  = data.get("email") or (stored[0] if stored else "")
    password    = data.get("password") or (stored[1] if stored else "")

    def _run():
        _state["scan_running"] = True
        _state["accounts"] = []
        try:
            _emit("Fetching JustDeleteMe database…", "info")
            jdm = fetch_jdm(force_refresh=force_jdm)
            jdm_count = len(set(v.get("name","") for v in jdm.values() if isinstance(v,dict)))
            if jdm_count > 0:
                src = "online" if force_jdm else "cache/online"
                _emit(f"JDM loaded: {jdm_count} services ({src})", "success")
            else:
                _emit("JDM data unavailable — scan will still work with built-in list", "warn")

            all_domains: set = set()

            if not browser_only and email_addr:
                _emit(f"Connecting to email: {email_addr}…", "info")
                try:
                    ed = scan_email(email_addr, password, dry_run=dry_run)
                    if len(ed) == 0 and not dry_run:
                        _emit("Email scan returned 0 domains — check App Password is correct", "warn")
                    else:
                        _emit(f"Email scan: {len(ed)} domains found", "success")
                    all_domains |= ed
                except Exception as email_err:
                    _emit(f"Email error: {email_err} — check App Password", "error")

            if not email_only:
                _emit("Scanning browser history…", "info")
                bd = scan_browser_history() if not dry_run else {"dryrun-browser.org","spotify.com","netflix.com","twitter.com"}
                _emit(f"Browser scan: {len(bd)} domains found", "success")
                all_domains |= bd

            all_domains -= NOISE_DOMAINS
            _emit(f"Deduped to {len(all_domains)} unique domains", "info")

            _emit("Matching against JustDeleteMe…", "info")
            accounts = match_to_jdm(all_domains, jdm)
            _state["accounts"] = accounts
            _emit(f"Done — {len(accounts)} accounts discovered", "done")
        except Exception as e:
            _emit(f"Scan error: {e}", "error")
            log.exception("Scan error")
        finally:
            _state["scan_running"] = False

    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"ok": True})

@app.route("/api/accounts", methods=["GET"])
def get_accounts():
    return jsonify(_state["accounts"])

@app.route("/api/stream")
def stream():
    def generate():
        while True:
            try:
                item = _state["log_queue"].get(timeout=30)
                yield f"data: {json.dumps(item)}\n\n"
            except queue.Empty:
                yield f"data: {json.dumps({'type':'ping'})}\n\n"
    return Response(stream_with_context(generate()),
                    mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache",
                             "X-Accel-Buffering": "no"})

@app.route("/api/open", methods=["POST"])
def open_url():
    url = request.json.get("url", "")
    if url:
        try:
            subprocess.Popen(["xdg-open", url],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            webbrowser.open(url)
    return jsonify({"ok": True})

@app.route("/api/gdpr", methods=["POST"])
def gdpr():
    data    = request.json
    stored  = load_creds()
    uemail  = stored[0] if stored else data.get("user_email","user@example.com")
    text    = generate_gdpr_email(
        data.get("name",""), data.get("contact_email",""),
        uemail, data.get("domain",""))
    out = APP_DIR / f"gdpr_{data.get('domain','unknown')}.txt"
    out.write_text(text)
    return jsonify({"text": text, "saved": str(out)})

@app.route("/api/automate", methods=["POST"])
def start_automate():
    if _state["auto_running"]:
        return jsonify({"error": "Automation already running"}), 400
    data      = request.json or {}
    indices   = data.get("indices", [])
    dry_run   = data.get("dry_run", False)
    headless  = data.get("headless", False)
    stored    = load_creds()
    email_addr = stored[0] if stored else ""
    password   = stored[1] if stored else ""
    targets   = [_state["accounts"][i] for i in indices
                 if 0 <= i < len(_state["accounts"])]
    if not targets:
        return jsonify({"error": "No accounts selected"}), 400

    def _run():
        _state["auto_running"]  = True
        _state["auto_results"] = []
        try:
            from browser_automation import run_automation
            _emit(f"Starting automation for {len(targets)} accounts…", "info")
            results = run_automation(
                accounts=targets, email=email_addr, password=password,
                app_dir=APP_DIR, dry_run=dry_run, headless=headless)
            _state["auto_results"] = results
            ok = sum(1 for r in results if r["status"] in ("deleted","submitted","dry_run"))
            _emit(f"Automation complete — {ok}/{len(results)} actioned", "done")
        except Exception as e:
            _emit(f"Automation error: {e}", "error")
            log.exception("Automation error")
        finally:
            _state["auto_running"] = False

    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"ok": True})

@app.route("/api/auto-results")
def auto_results():
    return jsonify(_state["auto_results"])

@app.route("/api/export")
def export():
    if not _state["accounts"]:
        return jsonify({"error": "No accounts to export"}), 400
    export_csv(_state["accounts"])
    return jsonify({"path": str(REPORT_CSV)})

# ── Main HTML page ────────────────────────────────────────────────────────────
HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>account-nuker</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Space+Mono:ital,wght@0,400;0,700;1,400&family=Syne:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>
:root {
  --bg:       #08090d;
  --bg2:      #0e1018;
  --bg3:      #141720;
  --border:   #1e2333;
  --border2:  #2a3050;
  --green:    #00e676;
  --cyan:     #00d4ff;
  --red:      #ff4757;
  --yellow:   #ffd43b;
  --orange:   #ff6b35;
  --dim:      #4a5580;
  --text:     #c8d0e8;
  --textdim:  #606880;
  --mono:     'Space Mono', monospace;
  --sans:     'Syne', sans-serif;
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

html, body {
  height: 100%;
  background: var(--bg);
  color: var(--text);
  font-family: var(--sans);
  overflow: hidden;
}

/* ── Animated background grid ── */
body::before {
  content: '';
  position: fixed; inset: 0;
  background-image:
    linear-gradient(var(--border) 1px, transparent 1px),
    linear-gradient(90deg, var(--border) 1px, transparent 1px);
  background-size: 40px 40px;
  opacity: 0.35;
  pointer-events: none;
  z-index: 0;
}

body::after {
  content: '';
  position: fixed; inset: 0;
  background: radial-gradient(ellipse 80% 60% at 50% -20%, rgba(0,212,255,0.07) 0%, transparent 70%);
  pointer-events: none;
  z-index: 0;
}

/* ── Layout ── */
#app {
  display: grid;
  grid-template-columns: 220px 1fr;
  grid-template-rows: 52px 1fr;
  height: 100vh;
  position: relative;
  z-index: 1;
}

/* ── Header ── */
header {
  grid-column: 1 / -1;
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 0 24px;
  background: rgba(8,9,13,0.9);
  border-bottom: 1px solid var(--border);
  backdrop-filter: blur(12px);
}

.logo {
  font-family: var(--mono);
  font-size: 13px;
  font-weight: 700;
  letter-spacing: 0.12em;
  color: var(--cyan);
  display: flex;
  align-items: center;
  gap: 8px;
}

.logo-icon {
  width: 22px; height: 22px;
  border: 2px solid var(--cyan);
  border-radius: 4px;
  display: flex; align-items: center; justify-content: center;
  font-size: 11px;
  box-shadow: 0 0 10px rgba(0,212,255,0.3);
}

.header-status {
  margin-left: auto;
  display: flex;
  align-items: center;
  gap: 10px;
  font-family: var(--mono);
  font-size: 11px;
  color: var(--textdim);
}

.status-dot {
  width: 6px; height: 6px;
  border-radius: 50%;
  background: var(--dim);
  transition: all 0.3s;
}
.status-dot.scanning { background: var(--cyan); box-shadow: 0 0 8px var(--cyan); animation: pulse 1s infinite; }
.status-dot.done     { background: var(--green); box-shadow: 0 0 8px var(--green); }
.status-dot.error    { background: var(--red); }

@keyframes pulse { 0%,100% { opacity:1; } 50% { opacity:0.4; } }

/* ── Sidebar ── */
nav {
  background: rgba(14,16,24,0.7);
  border-right: 1px solid var(--border);
  padding: 16px 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
  overflow-y: auto;
}

.nav-label {
  font-family: var(--mono);
  font-size: 9px;
  letter-spacing: 0.18em;
  color: var(--dim);
  padding: 14px 18px 6px;
  text-transform: uppercase;
}

.nav-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 9px 18px;
  font-size: 13px;
  font-weight: 600;
  color: var(--textdim);
  cursor: pointer;
  transition: all 0.15s;
  border-left: 2px solid transparent;
  position: relative;
}

.nav-item:hover { color: var(--text); background: rgba(255,255,255,0.03); }
.nav-item.active {
  color: var(--cyan);
  border-left-color: var(--cyan);
  background: rgba(0,212,255,0.05);
}

.nav-icon { font-size: 15px; width: 18px; text-align: center; }

.nav-badge {
  margin-left: auto;
  background: var(--cyan);
  color: var(--bg);
  font-family: var(--mono);
  font-size: 9px;
  font-weight: 700;
  padding: 2px 6px;
  border-radius: 10px;
  min-width: 18px;
  text-align: center;
}

/* ── Main content ── */
main {
  overflow-y: auto;
  padding: 24px;
  display: flex;
  flex-direction: column;
  gap: 20px;
}

/* ── Panels ── */
.panel {
  background: rgba(14,16,24,0.8);
  border: 1px solid var(--border);
  border-radius: 10px;
  overflow: hidden;
  backdrop-filter: blur(8px);
}

.panel-header {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 14px 18px;
  border-bottom: 1px solid var(--border);
  font-size: 13px;
  font-weight: 700;
  letter-spacing: 0.04em;
}

.panel-body { padding: 18px; }

/* ── Pages (views) ── */
.page { display: none; flex-direction: column; gap: 20px; }
.page.active { display: flex; }

/* ── Buttons ── */
.btn {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  padding: 9px 18px;
  border-radius: 7px;
  font-family: var(--sans);
  font-size: 13px;
  font-weight: 700;
  cursor: pointer;
  border: 1px solid transparent;
  transition: all 0.15s;
  white-space: nowrap;
}

.btn-primary {
  background: var(--cyan);
  color: var(--bg);
  border-color: var(--cyan);
}
.btn-primary:hover { background: #22e0ff; box-shadow: 0 0 20px rgba(0,212,255,0.35); }

.btn-ghost {
  background: transparent;
  color: var(--text);
  border-color: var(--border2);
}
.btn-ghost:hover { border-color: var(--cyan); color: var(--cyan); background: rgba(0,212,255,0.05); }

.btn-danger {
  background: transparent;
  color: var(--red);
  border-color: rgba(255,71,87,0.4);
}
.btn-danger:hover { background: rgba(255,71,87,0.1); border-color: var(--red); }

.btn-green {
  background: var(--green);
  color: var(--bg);
}
.btn-green:hover { box-shadow: 0 0 20px rgba(0,230,118,0.35); }

.btn:disabled { opacity: 0.4; cursor: not-allowed; pointer-events: none; }
.btn-sm { padding: 5px 12px; font-size: 11px; }

/* ── Form inputs ── */
.form-group { display: flex; flex-direction: column; gap: 6px; }
.form-label { font-size: 11px; font-weight: 700; color: var(--textdim); letter-spacing: 0.08em; text-transform: uppercase; }

input[type=text], input[type=email], input[type=password] {
  background: rgba(255,255,255,0.03);
  border: 1px solid var(--border2);
  border-radius: 7px;
  padding: 10px 14px;
  color: var(--text);
  font-family: var(--mono);
  font-size: 13px;
  outline: none;
  transition: border-color 0.15s;
  width: 100%;
}
input:focus { border-color: var(--cyan); box-shadow: 0 0 0 3px rgba(0,212,255,0.1); }

.toggle-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 0;
  border-bottom: 1px solid var(--border);
  font-size: 13px;
}
.toggle-row:last-child { border-bottom: none; }

.toggle {
  position: relative;
  width: 36px; height: 20px;
}
.toggle input { opacity: 0; width: 0; height: 0; }
.toggle-slider {
  position: absolute; inset: 0;
  background: var(--border2);
  border-radius: 20px;
  cursor: pointer;
  transition: 0.2s;
}
.toggle-slider::before {
  content: '';
  position: absolute;
  width: 14px; height: 14px;
  left: 3px; top: 3px;
  background: var(--textdim);
  border-radius: 50%;
  transition: 0.2s;
}
.toggle input:checked + .toggle-slider { background: rgba(0,212,255,0.3); }
.toggle input:checked + .toggle-slider::before {
  transform: translateX(16px);
  background: var(--cyan);
}

/* ── Accounts table ── */
.accounts-toolbar {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 18px;
  border-bottom: 1px solid var(--border);
  flex-wrap: wrap;
}

.filter-tabs {
  display: flex;
  gap: 4px;
  background: rgba(255,255,255,0.03);
  padding: 3px;
  border-radius: 8px;
  border: 1px solid var(--border);
}

.filter-tab {
  padding: 5px 12px;
  border-radius: 5px;
  font-size: 11px;
  font-weight: 700;
  cursor: pointer;
  color: var(--textdim);
  transition: all 0.15s;
  letter-spacing: 0.05em;
}
.filter-tab:hover { color: var(--text); }
.filter-tab.active { background: var(--border2); color: var(--text); }
.filter-tab[data-filter=easy].active    { color: var(--green); }
.filter-tab[data-filter=medium].active  { color: var(--yellow); }
.filter-tab[data-filter=hard].active    { color: var(--orange); }
.filter-tab[data-filter=impossible].active { color: var(--red); }

.search-box {
  flex: 1;
  min-width: 160px;
  max-width: 280px;
}
.search-box input {
  padding: 7px 12px;
  font-size: 12px;
}

.select-actions {
  display: flex;
  gap: 8px;
  margin-left: auto;
}

.accounts-table-wrap {
  overflow-x: auto;
}

table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}

thead th {
  padding: 10px 14px;
  text-align: left;
  font-family: var(--mono);
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 0.1em;
  color: var(--dim);
  text-transform: uppercase;
  border-bottom: 1px solid var(--border);
  white-space: nowrap;
}

tbody tr {
  border-bottom: 1px solid rgba(30,35,51,0.6);
  transition: background 0.1s;
}
tbody tr:hover { background: rgba(255,255,255,0.025); }
tbody tr.selected { background: rgba(0,212,255,0.05); }

td {
  padding: 11px 14px;
  vertical-align: middle;
}

td.td-check { width: 40px; }

input[type=checkbox] {
  width: 15px; height: 15px;
  accent-color: var(--cyan);
  cursor: pointer;
}

.diff-badge {
  display: inline-flex;
  align-items: center;
  padding: 3px 9px;
  border-radius: 20px;
  font-family: var(--mono);
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
}
.diff-easy       { background: rgba(0,230,118,0.12);  color: var(--green);  border: 1px solid rgba(0,230,118,0.25); }
.diff-medium     { background: rgba(255,212,59,0.1);  color: var(--yellow); border: 1px solid rgba(255,212,59,0.25); }
.diff-hard       { background: rgba(255,107,53,0.1);  color: var(--orange); border: 1px solid rgba(255,107,53,0.25); }
.diff-impossible { background: rgba(255,71,87,0.1);   color: var(--red);    border: 1px solid rgba(255,71,87,0.25); }
.diff-unknown    { background: rgba(74,85,128,0.2);   color: var(--dim);    border: 1px solid rgba(74,85,128,0.3); }

.auto-badge {
  font-family: var(--mono);
  font-size: 10px;
  color: var(--green);
}
.no-auto { color: var(--dim); }

.td-link a {
  color: var(--cyan);
  text-decoration: none;
  font-family: var(--mono);
  font-size: 11px;
  opacity: 0.8;
}
.td-link a:hover { opacity: 1; text-decoration: underline; }

.row-actions {
  display: flex;
  gap: 6px;
  opacity: 0;
  transition: opacity 0.15s;
}
tbody tr:hover .row-actions { opacity: 1; }

.empty-state {
  text-align: center;
  padding: 60px 20px;
  color: var(--textdim);
}
.empty-state-icon { font-size: 48px; margin-bottom: 14px; opacity: 0.4; }
.empty-state h3 { font-size: 16px; margin-bottom: 8px; color: var(--text); }
.empty-state p { font-size: 13px; }

/* ── Log console ── */
.log-console {
  background: rgba(4,5,8,0.9);
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 14px;
  height: 200px;
  overflow-y: auto;
  font-family: var(--mono);
  font-size: 12px;
  line-height: 1.7;
}

.log-line { display: flex; gap: 10px; }
.log-ts   { color: var(--dim); min-width: 56px; }
.log-info    { color: var(--cyan); }
.log-success { color: var(--green); }
.log-error   { color: var(--red); }
.log-done    { color: var(--green); font-weight: 700; }
.log-warn    { color: var(--yellow); }
.log-warn    { color: var(--yellow); }

/* ── Scan options grid ── */
.options-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

/* ── Stats bar ── */
.stats-bar {
  display: flex;
  gap: 20px;
  flex-wrap: wrap;
}

.stat-card {
  background: rgba(255,255,255,0.02);
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 14px 20px;
  min-width: 120px;
  flex: 1;
  position: relative;
  overflow: hidden;
}

.stat-card::before {
  content: '';
  position: absolute;
  top: 0; left: 0;
  width: 3px; height: 100%;
}

.stat-card.total::before  { background: var(--cyan); }
.stat-card.easy::before   { background: var(--green); }
.stat-card.medium::before { background: var(--yellow); }
.stat-card.hard::before   { background: var(--orange); }
.stat-card.impossible::before { background: var(--red); }

.stat-value {
  font-family: var(--mono);
  font-size: 28px;
  font-weight: 700;
  line-height: 1;
  margin-bottom: 4px;
}

.stat-label {
  font-size: 11px;
  color: var(--textdim);
  text-transform: uppercase;
  letter-spacing: 0.08em;
}

.stat-card.total  .stat-value { color: var(--cyan); }
.stat-card.easy   .stat-value { color: var(--green); }
.stat-card.medium .stat-value { color: var(--yellow); }
.stat-card.hard   .stat-value { color: var(--orange); }
.stat-card.impossible .stat-value { color: var(--red); }

/* ── Automation results ── */
.result-row {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 16px;
  border-bottom: 1px solid var(--border);
  font-size: 13px;
}

.result-status {
  font-family: var(--mono);
  font-size: 11px;
  padding: 3px 10px;
  border-radius: 20px;
  font-weight: 700;
  white-space: nowrap;
}

.status-deleted   { background: rgba(0,230,118,0.12); color: var(--green);  border: 1px solid rgba(0,230,118,0.3); }
.status-submitted { background: rgba(0,212,255,0.1);  color: var(--cyan);   border: 1px solid rgba(0,212,255,0.3); }
.status-error     { background: rgba(255,71,87,0.1);  color: var(--red);    border: 1px solid rgba(255,71,87,0.3); }
.status-dry_run   { background: rgba(255,212,59,0.1); color: var(--yellow); border: 1px solid rgba(255,212,59,0.3); }
.status-impossible{ background: rgba(74,85,128,0.2);  color: var(--dim);    border: 1px solid rgba(74,85,128,0.3); }
.status-captcha_timeout { background: rgba(255,107,53,0.1); color: var(--orange); border: 1px solid rgba(255,107,53,0.3); }

/* ── GDPR modal ── */
.modal-overlay {
  display: none;
  position: fixed; inset: 0;
  background: rgba(0,0,0,0.75);
  backdrop-filter: blur(4px);
  z-index: 100;
  align-items: center;
  justify-content: center;
}
.modal-overlay.open { display: flex; }

.modal {
  background: var(--bg2);
  border: 1px solid var(--border2);
  border-radius: 12px;
  width: 640px;
  max-width: 95vw;
  max-height: 85vh;
  overflow-y: auto;
  box-shadow: 0 20px 60px rgba(0,0,0,0.6);
}

.modal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px;
  border-bottom: 1px solid var(--border);
}

.modal-close {
  cursor: pointer;
  color: var(--textdim);
  font-size: 18px;
  line-height: 1;
  padding: 4px;
  border-radius: 4px;
  transition: color 0.15s;
}
.modal-close:hover { color: var(--text); }

textarea {
  width: 100%;
  background: rgba(4,5,8,0.9);
  border: 1px solid var(--border);
  border-radius: 7px;
  padding: 12px;
  color: var(--green);
  font-family: var(--mono);
  font-size: 12px;
  line-height: 1.7;
  resize: vertical;
  min-height: 280px;
  outline: none;
}

/* ── Progress bar ── */
.progress-bar {
  height: 3px;
  background: var(--border);
  border-radius: 2px;
  overflow: hidden;
  margin-top: 8px;
}
.progress-fill {
  height: 100%;
  background: linear-gradient(90deg, var(--cyan), var(--green));
  border-radius: 2px;
  transition: width 0.3s;
  width: 0;
}
.progress-fill.indeterminate {
  width: 40% !important;
  animation: slide 1.4s infinite ease-in-out;
}
@keyframes slide {
  0%   { transform: translateX(-150%); }
  100% { transform: translateX(350%); }
}

/* ── Scrollbar ── */
::-webkit-scrollbar { width: 5px; height: 5px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: var(--border2); border-radius: 3px; }
::-webkit-scrollbar-thumb:hover { background: var(--dim); }

/* ── Notification toast ── */
#toast {
  position: fixed;
  bottom: 24px;
  right: 24px;
  background: var(--bg3);
  border: 1px solid var(--border2);
  border-radius: 8px;
  padding: 12px 18px;
  font-size: 13px;
  max-width: 320px;
  transform: translateY(80px);
  opacity: 0;
  transition: all 0.25s;
  z-index: 200;
  box-shadow: 0 8px 32px rgba(0,0,0,0.4);
}
#toast.show { transform: translateY(0); opacity: 1; }
#toast.toast-success { border-color: rgba(0,230,118,0.4); color: var(--green); }
#toast.toast-error   { border-color: rgba(255,71,87,0.4); color: var(--red); }

/* ── Credentials page ── */
.creds-hint {
  background: rgba(0,212,255,0.06);
  border: 1px solid rgba(0,212,255,0.2);
  border-radius: 8px;
  padding: 12px 14px;
  font-size: 12px;
  color: var(--cyan);
  line-height: 1.6;
  font-family: var(--mono);
}
</style>
</head>
<body>
<div id="app">

<!-- ── Header ── -->
<header>
  <div class="logo">
    <div class="logo-icon">⚡</div>
    ACCOUNT-NUKER
  </div>
  <span style="color:var(--dim);font-size:11px;font-family:var(--mono);margin-left:8px">v1.2.0</span>
  <div class="header-status">
    <div id="statusDot" class="status-dot"></div>
    <span id="statusText">IDLE</span>
  </div>
</header>

<!-- ── Sidebar ── -->
<nav>
  <div class="nav-label">Setup</div>
  <div class="nav-item active" onclick="showPage('creds')">
    <span class="nav-icon">🔑</span> Credentials
  </div>

  <div class="nav-label">Scan</div>
  <div class="nav-item" onclick="showPage('scan')">
    <span class="nav-icon">📡</span> Scan Accounts
  </div>
  <div class="nav-item" onclick="showPage('accounts')">
    <span class="nav-icon">📋</span> Accounts
    <span id="navBadge" class="nav-badge" style="display:none"></span>
  </div>

  <div class="nav-label">Actions</div>
  <div class="nav-item" onclick="showPage('automate')">
    <span class="nav-icon">🤖</span> Automate
  </div>
  <div class="nav-item" onclick="showPage('gdpr')">
    <span class="nav-icon">📄</span> GDPR Emails
  </div>

  <div class="nav-label">Output</div>
  <div class="nav-item" onclick="doExport()">
    <span class="nav-icon">💾</span> Export CSV
  </div>
  <div class="nav-item" onclick="showPage('log')">
    <span class="nav-icon">🖥</span> Live Log
  </div>
</nav>

<!-- ── Main ── -->
<main>

  <!-- CREDENTIALS PAGE -->
  <div id="page-creds" class="page active">
    <div class="panel">
      <div class="panel-header">🔑 Email Credentials</div>
      <div class="panel-body" style="display:flex;flex-direction:column;gap:16px">
        <div style="background:rgba(255,71,87,0.08);border:1px solid rgba(255,71,87,0.35);border-radius:8px;padding:13px 15px;margin-bottom:4px">
          <div style="font-weight:700;color:var(--red);font-size:13px;margin-bottom:6px">⚠ Do NOT use your regular password</div>
          <div style="font-size:12px;line-height:1.7;color:var(--text)">
            You must create an <strong>App Password</strong> — a separate 16-character code.<br>
            Your normal password will always fail with <code style="background:var(--border);padding:1px 5px;border-radius:3px;font-size:11px">AUTHENTICATIONFAILED</code>.
          </div>
        </div>
        <div class="creds-hint" id="credsHint">
          <strong style="color:var(--cyan)">Gmail steps:</strong><br>
          1. Enable 2-Step Verification on your Google account<br>
          2. Go to <a href="#" onclick="openUrl('https://myaccount.google.com/apppasswords')" style="color:inherit;font-weight:700">myaccount.google.com/apppasswords</a><br>
          3. Select app: <em>Mail</em> → device: <em>Other</em> → Generate<br>
          4. Copy the 16-char password and paste it below<br><br>
          <strong style="color:var(--cyan)">Yahoo / Outlook / other:</strong><br>
          Yahoo: <a href="#" onclick="openUrl('https://login.yahoo.com/account/security')" style="color:inherit">login.yahoo.com/account/security</a> → App Passwords<br>
          Outlook: Use your regular password (enable IMAP first)
        </div>
        <div id="savedCredsBar" style="display:none;align-items:center;gap:12px;padding:10px 14px;background:rgba(0,230,118,0.07);border:1px solid rgba(0,230,118,0.2);border-radius:8px">
          <span style="color:var(--green);font-size:14px">✓</span>
          <span style="font-size:13px">Saved credentials for <strong id="savedEmail"></strong></span>
          <button class="btn btn-danger btn-sm" style="margin-left:auto" onclick="deleteCreds()">Delete</button>
        </div>
        <div id="credsForm" style="display:flex;flex-direction:column;gap:14px">
          <div class="form-group">
            <label class="form-label">Email Address</label>
            <input type="email" id="inputEmail" placeholder="you@gmail.com">
          </div>
          <div class="form-group">
            <label class="form-label">App Password</label>
            <input type="password" id="inputPassword" placeholder="xxxx xxxx xxxx xxxx">
          </div>
          <div style="display:flex;gap:10px">
            <button class="btn btn-primary" onclick="saveCreds()">💾 Save Credentials</button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- SCAN PAGE -->
  <div id="page-scan" class="page">
    <div class="panel">
      <div class="panel-header">⚙️ Scan Options</div>
      <div class="panel-body">
        <div class="options-grid" style="margin-bottom:18px">
          <div>
            <div class="toggle-row">
              <span>Scan Email Inbox</span>
              <label class="toggle"><input type="checkbox" id="optEmail" checked><div class="toggle-slider"></div></label>
            </div>
            <div class="toggle-row">
              <span>Scan Browser History</span>
              <label class="toggle"><input type="checkbox" id="optBrowser" checked><div class="toggle-slider"></div></label>
            </div>
          </div>
          <div>
            <div class="toggle-row">
              <span>Dry Run (no real scan)</span>
              <label class="toggle"><input type="checkbox" id="optDryRun"><div class="toggle-slider"></div></label>
            </div>
            <div class="toggle-row">
              <span>Force refresh JDM data</span>
              <label class="toggle"><input type="checkbox" id="optForceJDM"><div class="toggle-slider"></div></label>
            </div>
          </div>
        </div>
        <button class="btn btn-primary" id="btnScan" onclick="startScan()">
          📡 Start Scan
        </button>
        <div class="progress-bar" style="margin-top:14px"><div class="progress-fill" id="scanProgress"></div></div>
      </div>
    </div>

    <div class="panel">
      <div class="panel-header">🖥️ Scan Log</div>
      <div class="panel-body" style="padding:0">
        <div class="log-console" id="scanLog"><div class="log-line"><span class="log-ts">--:--:--</span><span class="log-info">Ready. Configure options and hit Start Scan.</span></div></div>
      </div>
    </div>
  </div>

  <!-- ACCOUNTS PAGE -->
  <div id="page-accounts" class="page">

    <div class="stats-bar" id="statsBar">
      <div class="stat-card total">
        <div class="stat-value" id="statTotal">0</div>
        <div class="stat-label">Total</div>
      </div>
      <div class="stat-card easy">
        <div class="stat-value" id="statEasy">0</div>
        <div class="stat-label">Easy</div>
      </div>
      <div class="stat-card medium">
        <div class="stat-value" id="statMedium">0</div>
        <div class="stat-label">Medium</div>
      </div>
      <div class="stat-card hard">
        <div class="stat-value" id="statHard">0</div>
        <div class="stat-label">Hard</div>
      </div>
      <div class="stat-card impossible">
        <div class="stat-value" id="statImpossible">0</div>
        <div class="stat-label">Impossible</div>
      </div>
    </div>

    <div class="panel">
      <div class="accounts-toolbar">
        <div class="filter-tabs">
          <div class="filter-tab active" data-filter="all" onclick="setFilter('all',this)">All</div>
          <div class="filter-tab" data-filter="easy" onclick="setFilter('easy',this)">Easy</div>
          <div class="filter-tab" data-filter="medium" onclick="setFilter('medium',this)">Medium</div>
          <div class="filter-tab" data-filter="hard" onclick="setFilter('hard',this)">Hard</div>
          <div class="filter-tab" data-filter="impossible" onclick="setFilter('impossible',this)">Impossible</div>
        </div>
        <div class="search-box">
          <input type="text" placeholder="Search services…" id="searchBox" oninput="renderTable()">
        </div>
        <div class="select-actions">
          <button class="btn btn-ghost btn-sm" onclick="selectAll()">Select All</button>
          <button class="btn btn-ghost btn-sm" onclick="selectNone()">None</button>
          <button class="btn btn-ghost btn-sm" onclick="selectEasy()">Easy Only</button>
        </div>
      </div>

      <div class="accounts-table-wrap">
        <table id="accountsTable">
          <thead>
            <tr>
              <th class="td-check"><input type="checkbox" id="selectAllBox" onchange="toggleAll(this)"></th>
              <th>Service</th>
              <th>Domain</th>
              <th>Difficulty</th>
              <th>Auto</th>
              <th>Deletion URL</th>
              <th></th>
            </tr>
          </thead>
          <tbody id="accountsTbody">
            <tr><td colspan="7"><div class="empty-state">
              <div class="empty-state-icon">📡</div>
              <h3>No accounts yet</h3>
              <p>Run a scan to discover your accounts</p>
            </div></td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- AUTOMATE PAGE -->
  <div id="page-automate" class="page">
    <div class="panel">
      <div class="panel-header">🤖 Playwright Automation</div>
      <div class="panel-body" style="display:flex;flex-direction:column;gap:16px">
        <div style="font-size:13px;color:var(--text);line-height:1.7">
          Opens a real Chromium browser window and attempts account deletion automatically.
          When a <strong style="color:var(--yellow)">CAPTCHA</strong> is detected, the browser pauses —
          solve it manually in the window, then press <kbd style="background:var(--border2);padding:2px 7px;border-radius:4px;font-size:11px">ENTER</kbd> in your terminal to resume.
        </div>

        <div style="background:rgba(255,212,59,0.06);border:1px solid rgba(255,212,59,0.2);border-radius:8px;padding:12px 14px;font-size:12px;color:var(--yellow);font-family:var(--mono)">
          ⚠ Requires an X11 or Wayland display. No accounts selected yet — go to Accounts tab and check the ones you want.
        </div>

        <div class="options-grid">
          <div>
            <div class="toggle-row">
              <span>Headless mode (no GUI window)</span>
              <label class="toggle"><input type="checkbox" id="autoHeadless"><div class="toggle-slider"></div></label>
            </div>
            <div class="toggle-row">
              <span>Dry run (simulate only)</span>
              <label class="toggle"><input type="checkbox" id="autoDryRun"><div class="toggle-slider"></div></label>
            </div>
          </div>
        </div>

        <div style="display:flex;align-items:center;gap:12px">
          <button class="btn btn-primary" id="btnAutomate" onclick="startAutomate()">
            🚀 Run Automation
          </button>
          <span id="autoSelCount" style="font-size:12px;color:var(--textdim)">0 accounts selected</span>
        </div>
        <div class="progress-bar"><div class="progress-fill" id="autoProgress"></div></div>
      </div>
    </div>

    <div class="panel" id="autoResultsPanel" style="display:none">
      <div class="panel-header">📊 Results</div>
      <div id="autoResultsList"></div>
    </div>
  </div>

  <!-- GDPR PAGE -->
  <div id="page-gdpr" class="page">
    <div class="panel">
      <div class="panel-header">📄 Generate GDPR / CCPA Erasure Email</div>
      <div class="panel-body" style="display:flex;flex-direction:column;gap:14px">
        <div class="form-group">
          <label class="form-label">Select Account</label>
          <select id="gdprSelect" style="background:rgba(255,255,255,0.03);border:1px solid var(--border2);border-radius:7px;padding:10px 14px;color:var(--text);font-family:var(--mono);font-size:13px;width:100%;outline:none">
            <option value="">— Run a scan first —</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Service Privacy Email (optional)</label>
          <input type="email" id="gdprContactEmail" placeholder="privacy@service.com">
        </div>
        <button class="btn btn-primary" onclick="generateGDPR()">✍️ Generate Email</button>
      </div>
    </div>

    <div class="panel" id="gdprOutput" style="display:none">
      <div class="panel-header" style="justify-content:space-between">
        <span>📋 Generated Email</span>
        <div style="display:flex;gap:8px">
          <button class="btn btn-ghost btn-sm" onclick="copyGDPR()">Copy</button>
          <button class="btn btn-ghost btn-sm" id="btnMailto" onclick="openGDPRMailto()">Open in Mail</button>
        </div>
      </div>
      <div class="panel-body" style="padding:14px">
        <textarea id="gdprText" readonly></textarea>
        <p id="gdprSaved" style="font-size:11px;color:var(--textdim);margin-top:8px;font-family:var(--mono)"></p>
      </div>
    </div>
  </div>

  <!-- LOG PAGE -->
  <div id="page-log" class="page">
    <div class="panel">
      <div class="panel-header" style="justify-content:space-between">
        <span>🖥️ Live Log</span>
        <button class="btn btn-ghost btn-sm" onclick="clearLog()">Clear</button>
      </div>
      <div class="panel-body" style="padding:0">
        <div class="log-console" id="mainLog" style="height:400px"></div>
      </div>
    </div>
  </div>

</main>
</div>

<!-- GDPR Modal (unused, kept for future) -->
<div class="modal-overlay" id="modalOverlay" onclick="closeModal()">
  <div class="modal" onclick="event.stopPropagation()">
    <div class="modal-header">
      <strong>GDPR Email</strong>
      <span class="modal-close" onclick="closeModal()">✕</span>
    </div>
    <div style="padding:18px">
      <textarea id="modalText" style="min-height:300px" readonly></textarea>
    </div>
  </div>
</div>

<div id="toast"></div>

<script>
// ── State ──────────────────────────────────────────────────────────────────
let accounts      = [];
let selected      = new Set();
let activeFilter  = 'all';
let lastGDPR      = { contactEmail: '', name: '', domain: '' };
let scanRunning   = false;
let autoRunning   = false;

// ── Navigation ─────────────────────────────────────────────────────────────
function showPage(id) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('page-' + id).classList.add('active');
  event.currentTarget.classList.add('active');

  if (id === 'accounts') refreshAccounts();
  if (id === 'automate') updateAutoSelCount();
  if (id === 'gdpr')     populateGDPRSelect();
}

// ── Credentials ────────────────────────────────────────────────────────────
async function loadCreds() {
  const r = await fetch('/api/creds');
  const d = await r.json();
  if (d.saved) {
    document.getElementById('savedCredsBar').style.display = 'flex';
    document.getElementById('savedEmail').textContent = d.email;
    document.getElementById('inputEmail').value = d.email;
    document.getElementById('credsForm').style.display = 'none';
  } else {
    document.getElementById('savedCredsBar').style.display = 'none';
    document.getElementById('credsForm').style.display = 'flex';
  }
}

async function saveCreds() {
  const email = document.getElementById('inputEmail').value.trim();
  const pass  = document.getElementById('inputPassword').value;
  if (!email || !pass) { toast('Enter email and password', 'error'); return; }
  await fetch('/api/creds', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({email, password: pass})
  });
  toast('Credentials saved', 'success');
  loadCreds();
}

async function deleteCreds() {
  if (!confirm('Delete saved credentials?')) return;
  await fetch('/api/creds', {method: 'DELETE'});
  document.getElementById('inputEmail').value = '';
  document.getElementById('inputPassword').value = '';
  document.getElementById('credsForm').style.display = 'flex';
  loadCreds();
  toast('Credentials deleted', 'success');
}

// ── Scan ───────────────────────────────────────────────────────────────────
async function startScan() {
  if (scanRunning) return;
  scanRunning = true;
  document.getElementById('btnScan').disabled = true;
  setStatus('scanning', 'SCANNING…');
  document.getElementById('scanProgress').classList.add('indeterminate');
  document.getElementById('scanLog').innerHTML = '';

  const stored = await (await fetch('/api/creds')).json();

  await fetch('/api/scan', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({
      email:       stored.email || '',
      password:    '',               // server loads from creds file
      dry_run:     document.getElementById('optDryRun').checked,
      email_only:  !document.getElementById('optBrowser').checked,
      browser_only:!document.getElementById('optEmail').checked,
      force_jdm:   document.getElementById('optForceJDM').checked,
    })
  });
}

// ── Accounts ───────────────────────────────────────────────────────────────
async function refreshAccounts() {
  const r = await fetch('/api/accounts');
  accounts = await r.json();
  renderTable();
  updateStats();
  updateNavBadge();
  populateGDPRSelect();
}

function setFilter(f, el) {
  activeFilter = f;
  document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  renderTable();
}

function renderTable() {
  const search  = document.getElementById('searchBox').value.toLowerCase();
  const tbody   = document.getElementById('accountsTbody');
  const visible = accounts.filter(a => {
    if (activeFilter !== 'all' && a.difficulty !== activeFilter) return false;
    if (search && !a.name.toLowerCase().includes(search) &&
        !a.domain.toLowerCase().includes(search)) return false;
    return true;
  });

  if (!visible.length) {
    tbody.innerHTML = `<tr><td colspan="7"><div class="empty-state">
      <div class="empty-state-icon">${accounts.length ? '🔍' : '📡'}</div>
      <h3>${accounts.length ? 'No matches' : 'No accounts yet'}</h3>
      <p>${accounts.length ? 'Try a different filter' : 'Run a scan to discover your accounts'}</p>
    </div></td></tr>`;
    return;
  }

  tbody.innerHTML = visible.map((a, vi) => {
    const idx  = accounts.indexOf(a);
    const diff = a.difficulty || 'unknown';
    const auto = ['easy','medium'].includes(diff);
    const url  = a.url || `https://${a.domain}`;
    const chk  = selected.has(idx) ? 'checked' : '';
    const sel  = selected.has(idx) ? 'selected' : '';
    return `<tr class="${sel}" data-idx="${idx}">
      <td class="td-check"><input type="checkbox" ${chk} onchange="toggleRow(${idx},this)"></td>
      <td><strong>${esc(a.name)}</strong></td>
      <td style="font-family:var(--mono);font-size:11px;color:var(--textdim)">${esc(a.domain)}</td>
      <td><span class="diff-badge diff-${diff}">${diff}</span></td>
      <td>${auto ? '<span class="auto-badge">✓ AUTO</span>' : '<span class="no-auto">—</span>'}</td>
      <td class="td-link"><a href="#" onclick="openUrl('${esc(url)}');return false">${esc(url.slice(0,48))}${url.length>48?'…':''}</a></td>
      <td>
        <div class="row-actions">
          <button class="btn btn-ghost btn-sm" onclick="openUrl('${esc(url)}')">Open</button>
          <button class="btn btn-ghost btn-sm" onclick="showGDPRFor(${idx})">GDPR</button>
        </div>
      </td>
    </tr>`;
  }).join('');
}

function toggleRow(idx, el) {
  if (el.checked) selected.add(idx); else selected.delete(idx);
  const row = el.closest('tr');
  if (el.checked) row.classList.add('selected'); else row.classList.remove('selected');
  updateAutoSelCount();
}

function toggleAll(el) {
  const visible = getVisibleIndices();
  if (el.checked) visible.forEach(i => selected.add(i));
  else            visible.forEach(i => selected.delete(i));
  renderTable();
  updateAutoSelCount();
}

function selectAll()  { accounts.forEach((_,i) => selected.add(i));    renderTable(); updateAutoSelCount(); }
function selectNone() { selected.clear(); renderTable(); updateAutoSelCount(); }
function selectEasy() {
  selected.clear();
  accounts.forEach((a,i) => { if (['easy','medium'].includes(a.difficulty)) selected.add(i); });
  renderTable(); updateAutoSelCount();
}

function getVisibleIndices() {
  const search = document.getElementById('searchBox').value.toLowerCase();
  return accounts.map((a,i) => ({a,i}))
    .filter(({a}) => {
      if (activeFilter !== 'all' && a.difficulty !== activeFilter) return false;
      if (search && !a.name.toLowerCase().includes(search) &&
          !a.domain.toLowerCase().includes(search)) return false;
      return true;
    }).map(({i}) => i);
}

function updateStats() {
  const counts = {total:0, easy:0, medium:0, hard:0, impossible:0};
  accounts.forEach(a => {
    counts.total++;
    if (counts[a.difficulty] !== undefined) counts[a.difficulty]++;
  });
  ['total','easy','medium','hard','impossible'].forEach(k => {
    document.getElementById('stat'+k.charAt(0).toUpperCase()+k.slice(1)).textContent = counts[k];
  });
}

function updateNavBadge() {
  const b = document.getElementById('navBadge');
  if (accounts.length) { b.textContent = accounts.length; b.style.display = 'inline'; }
  else b.style.display = 'none';
}

// ── Automate ───────────────────────────────────────────────────────────────
function updateAutoSelCount() {
  document.getElementById('autoSelCount').textContent =
    `${selected.size} account${selected.size!==1?'s':''} selected`;
  document.getElementById('btnAutomate').disabled = selected.size === 0;
}

async function startAutomate() {
  if (autoRunning || selected.size === 0) return;
  autoRunning = true;
  document.getElementById('btnAutomate').disabled = true;
  setStatus('scanning', 'AUTOMATING…');
  document.getElementById('autoProgress').classList.add('indeterminate');

  await fetch('/api/automate', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({
      indices:  [...selected],
      dry_run:  document.getElementById('autoDryRun').checked,
      headless: document.getElementById('autoHeadless').checked,
    })
  });

  // Poll for completion
  const poll = setInterval(async () => {
    const r = await fetch('/api/auto-results');
    const results = await r.json();
    if (!autoRunning || results.length > 0) {
      clearInterval(poll);
      showAutoResults(results);
    }
  }, 2000);
}

function showAutoResults(results) {
  autoRunning = false;
  document.getElementById('autoProgress').classList.remove('indeterminate');
  document.getElementById('autoProgress').style.width = '100%';
  setTimeout(() => document.getElementById('autoProgress').style.width = '0', 2000);

  const panel = document.getElementById('autoResultsPanel');
  const list  = document.getElementById('autoResultsList');
  panel.style.display = 'block';

  list.innerHTML = results.map(r => {
    const cls = 'status-' + r.status;
    const labels = {
      deleted:'✅ DELETED', submitted:'📤 SUBMITTED', error:'✗ ERROR',
      captcha_timeout:'⏱ CAPTCHA TIMEOUT', impossible:'⛔ IMPOSSIBLE',
      dry_run:'🧪 DRY RUN', not_attempted:'— SKIPPED'
    };
    return `<div class="result-row">
      <span style="font-weight:700;flex:1">${esc(r.service||r.domain)}</span>
      <span style="font-family:var(--mono);font-size:11px;color:var(--textdim)">${esc(r.domain)}</span>
      <span class="result-status ${cls}">${labels[r.status]||r.status}</span>
      <span style="font-size:11px;color:var(--textdim);max-width:200px;overflow:hidden;text-overflow:ellipsis">${esc(r.notes||'')}</span>
    </div>`;
  }).join('');

  setStatus('done', 'DONE');
  document.getElementById('btnAutomate').disabled = false;
}

// ── GDPR ───────────────────────────────────────────────────────────────────
function populateGDPRSelect() {
  const sel = document.getElementById('gdprSelect');
  sel.innerHTML = accounts.length
    ? '<option value="">— Select account —</option>' +
      accounts.map((a,i) => `<option value="${i}">${esc(a.name)} (${esc(a.domain)})</option>`).join('')
    : '<option value="">— Run a scan first —</option>';
}

function showGDPRFor(idx) {
  showPage('gdpr');
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('gdprSelect').value = idx;
}

async function generateGDPR() {
  const sel = document.getElementById('gdprSelect');
  const idx = parseInt(sel.value);
  if (isNaN(idx)) { toast('Select an account first', 'error'); return; }
  const acc = accounts[idx];
  const contactEmail = document.getElementById('gdprContactEmail').value ||
                       acc.email || `privacy@${acc.domain}`;

  lastGDPR = { contactEmail, name: acc.name, domain: acc.domain };

  const r = await fetch('/api/gdpr', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({
      name: acc.name, domain: acc.domain, contact_email: contactEmail
    })
  });
  const d = await r.json();
  document.getElementById('gdprText').value = d.text;
  document.getElementById('gdprSaved').textContent = '✓ Saved to ' + d.saved;
  document.getElementById('gdprOutput').style.display = 'block';
}

function copyGDPR() {
  navigator.clipboard.writeText(document.getElementById('gdprText').value);
  toast('Copied to clipboard', 'success');
}

function openGDPRMailto() {
  const subj = encodeURIComponent(`Right to Erasure Request — ${lastGDPR.name}`);
  openUrl(`mailto:${lastGDPR.contactEmail}?subject=${subj}`);
}

// ── Misc ───────────────────────────────────────────────────────────────────
async function doExport() {
  if (!accounts.length) { toast('Run a scan first', 'error'); return; }
  const r = await fetch('/api/export');
  const d = await r.json();
  if (d.path) toast('CSV saved: ' + d.path, 'success');
}

function openUrl(url) {
  fetch('/api/open', {method:'POST',headers:{'Content-Type':'application/json'},
        body: JSON.stringify({url})});
}

function clearLog() {
  document.getElementById('mainLog').innerHTML = '';
  document.getElementById('scanLog').innerHTML = '';
}

// ── SSE log stream ─────────────────────────────────────────────────────────
const evtSource = new EventSource('/api/stream');
evtSource.onmessage = e => {
  const d = JSON.parse(e.data);
  if (d.type === 'ping') return;

  appendLog(d, 'mainLog');
  appendLog(d, 'scanLog');

  if (d.type === 'done') {
    scanRunning = false;
    autoRunning = false;
    document.getElementById('btnScan').disabled = false;
    document.getElementById('scanProgress').classList.remove('indeterminate');
    setStatus('done', 'DONE');
    refreshAccounts();
    toast(d.message, 'success');
  } else if (d.type === 'error') {
    scanRunning = false;
    document.getElementById('btnScan').disabled = false;
    document.getElementById('scanProgress').classList.remove('indeterminate');
    setStatus('error', 'ERROR');
    toast(d.message, 'error');
  }
};

function appendLog(d, id) {
  const el = document.getElementById(id);
  if (!el) return;
  const line = document.createElement('div');
  line.className = 'log-line';
  line.innerHTML = `<span class="log-ts">${d.ts}</span><span class="log-${d.type}">${esc(d.message)}</span>`;
  el.appendChild(line);
  el.scrollTop = el.scrollHeight;
}

// ── UI helpers ─────────────────────────────────────────────────────────────
function setStatus(state, text) {
  const dot  = document.getElementById('statusDot');
  const span = document.getElementById('statusText');
  dot.className  = 'status-dot ' + state;
  span.textContent = text;
}

function toast(msg, type='success') {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className   = `toast-${type}`;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 3000);
}

function esc(str) {
  return String(str||'')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function closeModal() {
  document.getElementById('modalOverlay').classList.remove('open');
}

// ── Init ───────────────────────────────────────────────────────────────────
loadCreds();
refreshAccounts();
</script>
</body>
</html>"""

@app.route("/")
def index():
    return HTML

# ── Launch ────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import click as _click

    @_click.command()
    @_click.option("--port", default=PORT, help="Port to serve on")
    @_click.option("--no-browser", is_flag=True, help="Don't auto-open browser")
    def run(port, no_browser):
        """account-nuker GUI — serves a local web dashboard."""
        APP_DIR.mkdir(parents=True, exist_ok=True)
        print(f"\n  ⚡ account-nuker GUI starting…")
        print(f"  → http://localhost:{port}\n")
        if not no_browser:
            threading.Timer(1.2, lambda: webbrowser.open(f"http://localhost:{port}")).start()
        app.run(host="127.0.0.1", port=port, threaded=True, debug=False)

    run()
